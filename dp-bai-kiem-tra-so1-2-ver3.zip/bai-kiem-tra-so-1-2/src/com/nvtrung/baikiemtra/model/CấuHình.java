package com.nvtrung.baikiemtra.model;

@lombok.Getter
@lombok.Setter
@lombok.AllArgsConstructor
@lombok.NoArgsConstructor
public class CấuHình {
	private String loạiNguồn;
	private String chuỗiKếtNối;
}
