package com.nvtrung.dp.flyweight3;

@lombok.Data
@lombok.AllArgsConstructor
public class IntrinsicObject {
	private int r;
	private String màuSắc;
	private String vậtLiệu;
}
