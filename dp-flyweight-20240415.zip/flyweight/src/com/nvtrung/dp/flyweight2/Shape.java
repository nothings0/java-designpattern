package com.nvtrung.dp.flyweight2;

public interface Shape {
	void draw();
}