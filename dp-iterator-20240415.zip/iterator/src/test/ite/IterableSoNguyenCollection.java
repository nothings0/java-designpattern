package test.ite;

public interface IterableSoNguyenCollection {
	// Tạo ra bộ duyệt "chuẩn" 1-->n
	IteratorSoNguyen getIteratorSoNguyenChuan();
}
