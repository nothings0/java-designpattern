/**
 * 
 */
/**
 * 
 */
module composite2 {
}