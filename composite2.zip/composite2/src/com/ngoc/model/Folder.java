package com.ngoc.model;

import java.util.ArrayList;
import java.util.List;

public class Folder implements Component{
	public String tenFolder;
	private long size = 0;
	public String loai = "Nhom Tai Lieu";
	public String path;
	
	private List<Component> lst = new ArrayList<Component>();

	public String getTenFolder() {
		return tenFolder;
	}

	public void setTenFolder(String tenFolder) {
		this.tenFolder = tenFolder;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path + "/" + this.tenFolder;
	}

	@Override
	public long getTotalSize() {
		for (Component x : this.lst)
			this.size += x.getTotalSize();
		return this.size;
	}
	
	public void addFile(Component file) {
		lst.add(file);
	}

	public Folder(String tenFolder, long size) {
		super();
		this.path = tenFolder;
		this.tenFolder = tenFolder;
		this.size = size;
	}
}
