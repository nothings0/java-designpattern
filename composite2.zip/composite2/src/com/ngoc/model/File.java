package com.ngoc.model;

public class File implements Component{
	public String tenFile;
	private long size;
	public String loai = "Tai Lieu";
	public String path;
	
	public String getTenFile() {
		return tenFile;
	}

	public void setTenFile(String tenFile) {
		this.tenFile = tenFile;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = this.path + "/" + this.tenFile;
	}

	@Override
	public long getTotalSize() {
		// TODO Auto-generated method stub
		return this.size;
	}
	
	public File(String tenFile, long size) {
		super();
		this.path = tenFile;
		this.tenFile = tenFile;
		this.size = size;
	}
	
}
