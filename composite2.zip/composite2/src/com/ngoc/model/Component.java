package com.ngoc.model;

public interface Component {
	long getTotalSize();
}
