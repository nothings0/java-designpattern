package com.nvtrung.dp;

public class Utils {
	public static void rung() {
		System.out.println("Rung điện thoại");
	}

	public static void phátÂmThanh(int âmLượng, int sốLần) {
		System.out.printf("BEEP-BEEP với âm lượng %d trong %d lần\n", âmLượng, sốLần);
	}
}
